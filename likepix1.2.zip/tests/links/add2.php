<?php error_reporting(0); ?>

<?php

$id = $_GET['id'];

include("sql/conf.php");

$query = "SELECT * FROM linkdb WHERE id = $id";
$result = mysqli_query($db, $query); 

while ($row = mysqli_fetch_array($result)){

    echo $url = $row['1'];         

}

if ($url != ""){

    $url = file_get_contents($url);

    $q = explode("'", $url);

    $day = date("d");

    $month = date("m");

    $year = date("y");



    
    $date = $year . '-' . $day . '-' . $month ;

    for($i = 0; $i < 1000; $i++){

        $link_check = substr($q[$i], 0, 4); 

        if ($link_check == "http" or $link_check == "magn"){

            echo $q[$i] . "<br>";
        
            $link = $q[$i];      

            $query = "INSERT INTO linkdb (url, date) VALUES ('$link', '$date')";
            $result = mysqli_query($db, $query); 
        
        }

    }
}

$id++;

echo "
<script>
setTimeout('Redirect()', 10000);
function Redirect() 
{  
    window.location='add2.php?id=$id'; 
}
</script>";

?>