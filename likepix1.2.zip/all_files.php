﻿<?php error_reporting(0); 

$hostname = "http://localhost/likepix1.2/";

$category = $_GET['category'];

foreach (glob("categories/*") as $categories){


    foreach (glob("$categories/*") as $files){


        if ($category != ""){

            $select_category = explode("/", $categories);
            $select_category = $select_category[1];

            if($select_category == $category){
        
            echo $hostname . $files . '</br>';

            }

        }else{

        echo $hostname . $files . '</br>';

        }

    }

}


?>

<script>

alert('If you want a specific category you can type: all_files.php?category=cats');

</script>