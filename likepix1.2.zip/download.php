﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Downloading...
    </title>
  </head>

<?php

$id = $_GET['id'];

$hostname = $_GET['hostname'];

$category = $_GET['category'];

if ($category != ""){$category_header = "&category=$category";}

if ($hostname != ""){

    echo 'Hostname: ' . $hostname . '<br>';

    echo 'Current file: ' . $file_url = file_get_contents("$hostname/files.php?id=$id$category_header");

    echo "<br>";

    $find_category = explode("/", $file_url);

    echo 'Category: ' . $category = $find_category[4]; 

    $avoid_chars = array ('<', '>', '//', '.');

    $category = str_replace($avoid_chars, "", $category); 

    echo "<br>";

    echo 'Filename: ' . $filename = $find_category[5]; 

    $avoid_chars_name = array ('..');

    $filename = str_replace($avoid_chars_name, "", $filename); 

    if(!file_exists("categories/$category")){

        mkdir("categories/$category");
    }

    if(!file_exists("categories/$category/$filename")){

    // Workaround for URL bug (remove %EF%BB%BF from string)
    $file_url = stripslashes(trim($file_url));

    if (substr($file_url, 0, 3) == "\xef\xbb\xbf") {

        $file_url = substr($file_url, 3);
    }

    $content = file_get_contents("$file_url");
    file_put_contents("categories/$category/$filename", $content);

    $hash_content = sha1("categories/$category/$filename");

    $hash_download = file_get_contents("$hostname/fileinfo/$hash_content");

    if(!file_exists("fileinfo/$hash_content")){

        file_put_contents("fileinfo/$hash_content", $hash_download);
    }

    echo "<br> Downloading file info: ($hash_content)";

} 

    $id++;

    echo "
<script>
setTimeout('Redirect()', 10000);
function Redirect() 
{  
    window.location='download.php?id=$id&hostname=$hostname$category_header'; 
}
</script>";


} else {

    $id++;

    echo "<script>
var signo = window.prompt('Insert hostname e.g: http://localhost/likepix');
window.location='download.php?' + 'hostname=' + signo + '$category_header'; 

</script>";
}

?>