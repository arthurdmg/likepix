﻿<?php error_reporting(0); 

$hostname = "http://localhost/likepix1.2/";

foreach (glob("hashes/*") as $hashes){


    $hash = explode("/", $hashes);
    $hash = $hash[1];
      
    $total_likes = file_get_contents("$hashes/total.txt");
    $hash_info = file_get_contents("fileinfo/$hash");

    echo "$hash_info - ($total_likes) </br>";
}


?>