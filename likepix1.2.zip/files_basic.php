﻿<?php error_reporting(0); 

$hostname = "http://localhost/likepix1.2/";

$id = $_GET['id'];  
	
if (!$id){$id = 0;}

$c = 0;

foreach (glob("categories/*") as $categories){


    foreach (glob("$categories/*") as $files){


        if ($c == $id){

            echo $hostname . $files;
    
        }

    $c++;
    }

}


?>