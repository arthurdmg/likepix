﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      URLs
    </title>
  </head>

  <style type="text/css">   
    body{

      font-family: Arial;
      color: #666666;
    }

    a{
       
      color: #333;
      padding-left: 40px;
      text-decoration: none;
    }

    a:hover{
       
      color: #666;
    }

    i{      
 
      padding: 40px;
      letter-spacing: 4px;
    }


  </style>
<br>
<div align='center'>
<a href='indexer.php'>refresh</a>
</div>

<?php

$url = $_GET['url'];
$description = $_GET['description'];

if ($url != "" && $description != ""){

$avoid_chars_link = array ('<', '>');

$url = str_replace($avoid_chars_link, "", $url); 
$description = str_replace($avoid_chars_link, "", $description); 

        $write = fopen("urls.html", "a");
        fwrite($write, "<h1><a href='$url' target='_blank'>$url</a></h1><i>$description</i><hr></hr>");
        fclose($write);      

} else {

    echo "<script>

var url = window.prompt('Insert URL');
var description = window.prompt('description');

if(url && name){window.location='indexer.php?' + 'url=' + url + '&description=' + description;}

</script>";
}

include("urls.html"); 

?>