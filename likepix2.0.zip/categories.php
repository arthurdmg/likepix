﻿<?php error_reporting(0); session_start(); $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      <?php echo $lbl_u_categories; ?>
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <style type="text/css">   

     body{

       color: #666666;
       font-family: arial;
       letter-spacing: 2px;
     }
 
    a{

      padding: 10px;
      color: #666666;
      text-decoration: none;
    }

  </style>

  <body>
  
    <br>

<?php

foreach (glob("categories/*") as $category){


    foreach (glob("$category/*") as $subcategory){


        $name = explode('/', $subcategory);

        echo "<a href='index.php?category=$name[2]&filetype=$name[1]'>$name[2] ($name[1])</a> /";
    }
}

?>


    <div align='center'><br><br>
      <a href='index.php'><u>Back</u></a>
    </div>
    <div id='ifrm'>
  </body>
</html>
