﻿<div align='center'>

<?php error_reporting(0); 

include("config.php");

$category = $_GET['category'];

foreach (glob("categories/*") as $categories){


    foreach (glob("$categories/*") as $subcategories){


        foreach (glob("$subcategories/*") as $files){


            if ($category != ""){

                $select_category = explode("/", $subcategories);
                $select_category = $select_category[2];

                if($select_category == $category){
        
                echo $hostname . $files . '</br>';

                }

            }else{

            $select_filename = explode("/", $files);
            $filename  = $select_filename[3];

            if($select_filename[2] == "thumbs"){continue;}

            if(!file_exists("$categories/thumbs/$filename.jpg")){
            $img_src = $files;
            }else{
            $img_src = "$categories/thumbs/$filename.jpg";
            }

            echo "<a href='$img_src' target='_blank'><img src='$img_src'></a></br>";
            echo "<a href='$files' target='_blank'>$files</a>" . '</br></br>';

            }
        }
    }
}


?>

</div>
