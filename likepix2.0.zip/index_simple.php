﻿<?php error_reporting(0); session_start(); if($_GET['lang'] != "") {$_SESSION['langs'] = $_GET['lang'];} $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      Home
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/sourcecode/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Liked!");
    }
  </script>


  <style type="text/css">   
    body{

      font-family: Arial;
      color: #666666;
    }
 
    input{

      border: 2px solid #aaa;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

      padding: 10px;
      text-decoration: none;
    }

    a:hover{

      background-color: #DDD;
    }



  </style>

  <body>
    <div align='center'>
    <form action="index_simple.php" method="POST">
     <a href='sourcecode.zip' style='color: #FFA500;'>Sourcecode</a>
     <a href='index_simple.php?lang=eng'>Eng</a> <a href='index_simple.php?lang=pt-br'>Pt-br</a>          
     <?php echo $lbl_option_get; ?>
     <a href='categories.php'><?php echo $lbl_u_categories; ?></a>

     <a href='download.php'>Feed</a>
     <a href='all_files.php'>Files</a>   
     <a href='index_simple.php'>Home</a>

     <input type="text" placeholder="<?php echo $lbl_name; ?>" name="search">    
     <input type="text" placeholder="<?php echo $lbl_category; ?>" name="category">   
     <input type="submit" value="<?php echo $lbl_search; ?>" />   

     &nbsp; &nbsp;  

     <img src='logos/BTC.png' height='25px'></a> &nbsp;  
     <img src='logos/ETH.png' height='25px'></a> &nbsp;     

   </form>
  </div>
  <hr style='color: #EEE;'></hr>

<?php

if(!file_exists("categories")){

    mkdir("categories");
}

if(!file_exists("categories/thumbs")){

    mkdir("categories/thumbs");
}

if(!file_exists("categories/files")){

    mkdir("categories/files");
}


$start = $_GET['start'];  

$category = $_POST['category']; 
if ($category == ""){$category = $_GET['category'];}
	
if (!$start){$start = 0;}

$c = 0;
$limit = 20;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];
$search = strtolower($search);
$search = str_replace(" ", "_", $search); 

$slash_break = 2;

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

if ($search != ""){

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){
   

        $item = explode('/', $picture);

        $picture_lowercase = strtolower($item[$slash_break]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($item[$slash_break]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $thumb_dir = '';

                $item = $item[$slash_break];

                $file_ext = substr($item, -3);
                $file_ext = strtolower($file_ext);

                if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){

                    $thumb_dir = $picture;
                } 

                if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                    $thumb_dir = 'img/nopic.jpg';
                }        

                if(file_exists('categories/thumbs/' . $item . '.jpg')){

                    $thumb_dir = 'categories/thumbs/' . $item . '.jpg';
                }   
 
                $item_len = strlen($item);
                if ($item_len > 20){$item = substr($item, 0, 20) . "...";} 

                if ($collum > 3){$collum = 0;}  
                $collum++;   

                $content[$collum] = $content[$collum] . "<a href='$thumb_dir' target='_blank'><img src='$thumb_dir' height='200px'></a><br><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a><br><br>";
                $search_break++;       
            }

        $entry++;
        if($search_break == $limit){break;}
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>$lbl_no_results</h1></div>";}

}else{

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        if ($c >= $ini and $c < $end){
 
            $thumb_dir = '';

            $item = explode('/', $picture);
            $item = $item[$slash_break];

            $file_ext = substr($item, -3);
            $file_ext = strtolower($file_ext);

            if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){

                $thumb_dir = $picture;
            } 

            if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                $thumb_dir = 'img/nopic.jpg';

            }        

           if(file_exists('categories/thumbs/' . $item . '.jpg')){

               $thumb_dir = 'categories/thumbs/' . $item . '.jpg';
           }     

           $item_len = strlen($item);

           if ($item_len > 20){$item = substr($item, 0, 20) . "...";}

           if ($collum > 3){$collum = 0;}
 
           $collum++;   

           $content[$collum] = $content[$collum] . "<a href='$thumb_dir' target='_blank'><img src='$thumb_dir' height='200px'></a><br><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a><br><br>";
           $search_break++;             
        }

    $c++;
    if($search_break == $limit){break;}
    }

}
?>

<div align='center'>
<table>

<tr>

<td valign='top'><?php echo $content[1]; ?>
</td>

<td valign='top'><?php echo $content[2]; ?>
</td>

<td valign='top'><?php echo $content[3]; ?>
</td>

</tr>
</table>

<?php
echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index_simple.php?start=$i&search=$search&category=$category'>$i</a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index_simple.php?start=$i&search=$search&category=$category'>$i</a>";
    }

} 

echo "</div>";

?>

    <div align='center'><br><br>
      <a href='sourcecode.zip' style='text-decoration: none; color: #666666;'>sourcecode</a></a>
      <a href='#' style='text-decoration: none; color: #666666;' OnClick="alert('The site is ​​not responsible for the files uploaded by the users or hosted by third parties.');">Terms of use</a></a>
    </div>
    <div id='ifrm'>

  </body>
</html>