﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Paste
    </title>
  </head>

<?php

$content = $_GET['content'];

if ($content != ""){

        $write = fopen("paste.txt", "a");
        fwrite($write, "$content<hr></hr>");
        fclose($write);
        include("paste.txt"); 

} else {

    echo "<script>
var signo = window.prompt('Paste anything');

if(signo){
window.location='paste.php?' + 'content=' + signo; 
}
</script>";
}

 $filesize = filesize("paste.txt");
 if ($filesize > 5000){unlink("paste.txt");}
?>