﻿<div align='center'>
  
 <table width='95%'>

<?php error_reporting(0); 

include("config.php");

$category = $_GET['category'];

$c = 0;

foreach (glob("categories/*") as $categories){


    foreach (glob("$categories/*") as $subcategories){

  
        foreach (glob("$subcategories/*") as $files){


            if ($category != ""){

                $select_category = explode("/", $subcategories);
                $select_category = $select_category[2];

                if($select_category == $category){
        
                echo $hostname . $files . '</br>';

                }

            }else{

            $select_filename = explode("/", $files);
            $filename  = $select_filename[3];

            if($select_filename[2] == "thumbs"){continue;}

            if(!file_exists("$categories/thumbs/$filename.jpg")){
            $img_src = $files;
            }else{
            $img_src = "$categories/thumbs/$filename.jpg";
            }
           
            }

        $simple = $simple . $files . '</br>';
        }

    $select_category = explode("/", $subcategories);

    $func_name = $select_category[1] . $select_category[2];
  
    if($simple != ""){
        echo $select_category = "<a href='#' onClick='hello(" . '"' . $simple . '"'. ");'>$select_category[1] . $select_category[2]</a> &nbsp;"; 

    echo "
<script>
function hello(a){

var contents = document.getElementById('contents');
contents.innerHTML = a;}

</script>
";
    }   

    $subcatecory_show[$c] = $show_file;
    $c++;
    $simple = "";

    }
}

?>

<br><br>

<div id='contents'></div>

</table>
</div>
