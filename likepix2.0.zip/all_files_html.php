﻿<?php error_reporting(0); 

include("config.php");

$category = $_GET['category'];

foreach (glob("categories/*") as $categories){


    foreach (glob("$categories/*") as $subcategories){


        foreach (glob("$subcategories/*") as $files){


            if ($category != ""){

                $select_category = explode("/", $subcategories);
                $select_category = $select_category[2];

                if($select_category == $category){
        
                echo $hostname . $files . '</br>';

                }

            }else{

            echo "<a href='$files' target='_blank'>$files</a>" . '</br>';

            }
        }
    }
}


?>

<script>

alert('If you want a specific category you can type: all_files.php?category=cats');

</script>