﻿<?php

$hostname = "http://localhost/sourcecode/";
$application_name = "";
$application_version = "";
$ethereum_donation_addr = "";
$bitcoin_donation_addr = "";

?>