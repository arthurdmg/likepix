<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="utf-8">
<title>Coins</title>
<link rel="stylesheet" href="../default.css">
</head>

<body>

<?php
        
    include("sql_conf.php");
   
    $user = $_SESSION['user'];

    echo $file = $_GET['file'];

    echo "<form action='coins.php?file=$file' method='POST'>

    <input type='text' name='coins_value'>

    <input type='submit' class='btn_style_01'>

    </form>";

    if ($user == ""){echo "</br><a href='login.php'>Please log-in!</a>"; die;}

    // Check if file exists in DB 	
    $query = "SELECT * FROM files WHERE name LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
        }


    if ($file_db == ""){

    $query = "INSERT INTO files (name) VALUES ('$file')";
    $result = mysqli_query($db, $query);
     
    }    

    echo "</br>";

    $chars = array ('<', '>', "'", '"', '.', ',', '*', '+', '=', '$');

    $coins_value = $_POST['coins_value'];

    $coins_check = str_replace($chars,"", $coins_value);

    $coins_len = strlen($_POST['coins_value']);

    $coins_check_len = strlen($coins_check);    

    if ($coins_len > $coins_check_len){echo "<b>Digite apenas valores inteiros!</b>"; die;}

    if (!file_exists("../categories/$file")){echo "Esse arquivo n�o existe!"; die;}
    if ($file == ""){echo "Nenhum arquivo selecionado."; die;}    

    $query = "SELECT * FROM users WHERE user LIKE '$user'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $coins_db = $row['2'];  
        }  

    echo "Saldo: " . $coins_db . "</br>";
    echo $coins_Value . "</br>"; 
    echo "Digite somente valores inteiros (por exemplo: 1, 2, 5, 10)</br>";
    
    if (!$coins_value){echo "Nenhum valor inserido."; die;} 

    if ($coins_value <= 0){echo "Nenhum valor inserido."; die;} 

    //$float_check = is_float($coins_value);

    //if($float_check == 1){echo "Digite apenas valores inteiros!"; die;}

    if ($coins_db == "" ){"Conta sem saldo. Compre wcoins agora"; die;}

    if ($coins_value > $coins_db){echo "Voc� n�o tem saldo suficiente!"; die;}

    $number_check = is_numeric($coins_value);
 
    if($number_check == 0){echo "Digite apenas valores inteiros!"; die;}
   
    $balance = $coins_db - $coins_value;

    $query = "UPDATE users SET coins = '$balance' WHERE user = '$user'";


    $result = mysqli_query($db, $query);

    $query = "INSERT INTO coins (file, user, coins) VALUES ('$file', '$user', '$coins_value')";


    mysqli_query($db, $query);

    
    // In coins table count the numbers of views of the file

    $query = "SELECT file, SUM(coins), COUNT(file) FROM coins WHERE file LIKE '$file' GROUP BY file HAVING COUNT(file) > 0";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){

            $coins = $row['1'];     	
        }

    // Update the coins number in the file table


    $query = "UPDATE files SET coins = '$coins' WHERE name = '$file'";


    $result = mysqli_query($db, $query);   

    echo "<div align='center'>$views</div>";   

    echo "<b>Opera��o realizada com sucesso.</b> Novo saldo: $balance";

?>


</body>

</html>
