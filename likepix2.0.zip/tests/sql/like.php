<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />  
<title>Like</title>  
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

if ($user){

    $file = $_GET['file'];

    include("sql_conf.php"); 

    // Check if file exists
    if (!file_exists("../categories/$file")){echo "File not found!"; die;}

    // Check if file exists in DB 	
    $query = "SELECT * FROM files WHERE name LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
        }


    if ($file_db == ""){

    $query = "INSERT INTO files (name) VALUES ('$file')";
    $result = mysqli_query($db, $query);
     
    }    



    // In likes table search for the user and file liked

    $query = "SELECT * FROM likes WHERE file LIKE '$file' and user LIKE '$user'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $user_db = $row['1'];
        }	


    if ($file_db != "" and $user_db != ""){echo "Already liked!"; die;} else{

	// In likes table insert user and file if not voted



        $query = "INSERT INTO likes (file, user) VALUES ('$file', '$user')";


        mysqli_query($db, $query);

        echo "Liked!";
	
    }

    // In like table count the numbers of likes of the file

    $query = "SELECT file, COUNT(file) FROM likes WHERE file LIKE '$file' GROUP BY file HAVING COUNT(file) > 0";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){

            $likes = $row['1'];     	
        }

    // Update the likes number in the file table


    $query = "UPDATE files SET likes = '$likes' WHERE name = '$file'";


    $result = mysqli_query($db, $query);

}else{

echo "<a href='login.php'>Please log-in!</a>";

}

include("ads.php");

?>

</body>

</html>
