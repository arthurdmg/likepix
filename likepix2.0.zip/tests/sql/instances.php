<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Instances</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<div align='center'>
<form method="post" action="valida_instances.php">

    </br>
    <h1>Instances</h1>

    <input type="text" name="name" placeholder='Name' maxlength="50"></br>
    
    <input type="text" name="url" placeholder='URL' maxlength="50"></br>
   
    <input type="text" name="categories" placeholder='Categories (comma separated)' maxlength="50"></br></br>

    <img src="captcha.php" alt="c�digo captcha" />
    </br>
    <input type="text" name="captcha" placeholder='Captcha code' id="captcha" />

    </br></br>

    <input type="submit" value=" Add " class="btn_style_01" />
     


</form>
</div>
</body>

</html>
