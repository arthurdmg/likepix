<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Subscribe</title>
<link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

    $subs = $_GET['subs'];

    include("sql_conf.php");
    
    $query = "SELECT * FROM users WHERE user LIKE '$subs'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $user_db = $row['0'];
        }



    if ($user_db == ""){echo "User not found!"; die;}

    if($subs and $user){	


        $query = "SELECT * FROM subscriptions WHERE subscription LIKE '$subs' and user LIKE '$user'";


        $result = mysqli_query($db, $query);

            while ($row = mysqli_fetch_array($result)){
                $subs_db = $row['0'];
                $user_db = $row['1'];
            }	


	    if ($subs_db != "" and $user_db != ""){

                $query = "DELETE FROM subscriptions WHERE subscription LIKE '$subs' and user LIKE '$user'";


                mysqli_query($db, $query);

                echo "Subscription undone!</br>";

            } else {


                $query = "INSERT INTO subscriptions (subscription, user) VALUES ('$subs', '$user')";


                mysqli_query($db, $query);

                echo "Subscription done!</br>";

   	    }

    } else {echo "Please log-in!";}

?>

</body>

</html>
