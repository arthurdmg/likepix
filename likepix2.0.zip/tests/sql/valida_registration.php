<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

$user = $_POST['username'];
$pass = $_POST['password'];

    if ($user == "" or $pass == ""){
	echo "Blank fields!"; die;
    }	

    if (!ctype_alnum($user)) {
        echo "Type only letters or numbers!"; die;
    }

    if (!ctype_alnum($pass)) {
        echo "Type only letters or numbers!"; die;
    }

    if( $_SESSION['captcha'] == $_POST['captcha']){ 
	
	include("sql_conf.php");

        $query = "SELECT * FROM users WHERE user LIKE '$user'";


        $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $user_db = $row['0'];
        }

        if ($user_db != ""){echo "Username already exists!"; die;}



        $query = "INSERT INTO users (user, pass, coins, info) VALUES ('$user', '$pass', '0', '')";


        mysqli_query($db, $query);

        echo "<h1><a href='../index.php'>Registration successful!</a></h1>";
	$_SESSION['user'] = $user;

    }else{

        echo "<h1>Wrong captcha</h1>";

    }

?>

</body>

</html>
