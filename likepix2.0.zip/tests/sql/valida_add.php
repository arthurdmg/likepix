<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $url = $_POST['url'];
    $comment = $_POST['comment'];
    $user = $_SESSION['user'];

    if ($url == "" or $comment == ""){
	echo "Blank fields!"; die;
    }	

    $chars = array ('<', '>', "'", '"', '*');

    $url = str_replace($chars, "", $url); 
    $comment = str_replace($chars, "", $comment); 

    if( $_SESSION['captcha'] == $_POST['captcha']){ 
	
	include("sql_conf.php");

        $query = "SELECT * FROM files WHERE name LIKE '$url'";


        $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $user_db = $row['0'];
        }

        if ($user_db != ""){echo "Filename already exists!"; die;}

        $day = date("d");

        $month = date("m");

        $year = date("y");



        $symbol = "-";
	
        $date = $year . $symbol . $month . $symbol . $day;



        $query = "INSERT INTO files (name, user, date, commentary, coins, views, likes) VALUES ('$url', '$user', '$date', '$comment', '0', '0', '0')";
        $result = mysqli_query($db, $query);
        mysqli_query($db, $query);

        echo "<h1><a href='add.php'>Add successful!</a></h1>";
	$_SESSION['user'] = $user;

    }else{

        //echo "<h1>Wrong captcha</h1>";

    }

?>

</body>

</html>
