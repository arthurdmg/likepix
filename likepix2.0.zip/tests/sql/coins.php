<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="utf-8">
<title>Coins</title>
<link rel="stylesheet" href="../default.css">
</head>

<body>

<?php
        
    include("sql_conf.php");
   
    $user = $_SESSION['user'];

    echo $file = $_GET['file'];

    if ($user == ""){echo "</br><a href='login.php'>Please log-in!</a>"; die;}

    // Check if file exists in DB 	
    $query = "SELECT * FROM files WHERE name LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
        }


    if ($file_db == ""){

    $query = "INSERT INTO files (name) VALUES ('$file')";
    $result = mysqli_query($db, $query);
     
    }    

    // In search for the user and file coined

    $query = "SELECT * FROM coins WHERE file LIKE '$file' and user LIKE '$user'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $user_db = $row['1'];
        }	


    if ($file_db != "" and $user_db != ""){echo "Already coined!"; die;} else{

        $query = "SELECT * FROM users WHERE user LIKE '$user'";


        $result = mysqli_query($db, $query);

            while ($row = mysqli_fetch_array($result)){
                $coins_db = $row['2'];  
            }  

        
    if (!file_exists("../categories/$file")){echo "Esse arquivo n�o existe!"; die;}
    if ($file == ""){echo "Nenhum arquivo selecionado."; die;}  
    if ($coins_db == "" or $coins_db == 0){"Conta sem saldo. Compre wcoins agora"; die;}


	// In likes table insert user and file if not voted



        
        $query = "INSERT INTO coins (file, user, coins) VALUES ('$file', '$user', '1')";


        mysqli_query($db, $query);

        echo "Coined!";

    $balance = $coins_db - 1;

    $query = "UPDATE users SET coins = '$balance' WHERE user = '$user'";


    $result = mysqli_query($db, $query);

    $query = "INSERT INTO coins (file, user, coins) VALUES ('$file', '$user', '$coins_value')";


    mysqli_query($db, $query);
	
    }
 
    
    // Count the numbers of coins of the file

    $query = "SELECT file, SUM(coins), COUNT(file) FROM coins WHERE file LIKE '$file' GROUP BY file HAVING COUNT(file) > 0";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){

            $coins = $row['1'];     	
        }

    // Update the coins number in the file table


    $query = "UPDATE files SET coins = '$coins' WHERE name = '$file'";


    $result = mysqli_query($db, $query);   

    echo "<div align='center'>$views</div>";   

    echo "<b>Opera��o realizada com sucesso.</b> Novo saldo: $balance";

?>


</body>

</html>
