<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Logout</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

$_SESSION['user'] = "";

echo "<h1><a href='../index.php'>Done</a></h1>";

include("ads.php");

?>

</body>

</html>
