<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

   $name = $_POST['name'];
   $url = $_POST['url'];
   $categories = $_POST['categories'];

    if ($name == "" or $url == "" or $categories == ""){
	echo "Blank fields!"; die;
    }	
    
    $chars = array ('<', '>', "'", '"', '$', '=', '*');

    $name = str_replace($chars, "", $name); 
    $url = str_replace($chars, "", $url); 
    $categories = str_replace($chars, "", $categories); 

      if( $_SESSION['captcha'] == $_POST['captcha']){ 
	
	include("sql_conf.php");

        $query = "SELECT * FROM instances WHERE name LIKE '$name'";


        $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $name_db = $row['0'];
        }

        if ($name_db != ""){echo "Name already exists!"; die;}



        $query = "INSERT INTO instances (name, url, categories) VALUES ('$name', '$url', '$categories')";


        mysqli_query($db, $query);

        echo "<h1><a href='../index.php'> Instance registration successful!</a></h1>";
	$_SESSION['user'] = $user;

    }else{

        echo "<h1>Wrong captcha</h1>";

    }

?>

</body>

</html>
