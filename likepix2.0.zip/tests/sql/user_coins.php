<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />  
<title>MyCoins</title>  
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

if ($user){

    $file = $_GET['file'];

    include("sql_conf.php"); 

    // In likes table search for the user and file liked

    echo "Welcome <b>$user</b> </br></br><table width='80%' style='border: 1px solid #EEE;'><tr><td>File</td><td>User</td><td>Coins</td></tr>"; 

    $query = "SELECT * FROM coins WHERE user LIKE '$user'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $user_db = $row['1'];
                $coins_db = $row['2'];

                $user_coins+= $row['2']; 
    
    echo "<tr><td><a href='views.php?file=$file_db' target='_blank'>$file_db</a></td><td>$user_db</td><td>$coins_db</td></tr>";   	
    
    }

    echo "</table>";

    echo "Coins asseted: <b>$user_coins</b>";


    include ("stats.php");
    

}else{

echo "<a href='login.php'>Please log-in!</a>";

}


?>

</body>

</html>
