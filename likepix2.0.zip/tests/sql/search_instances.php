<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Instances</title>
  <link rel="stylesheet" href="../default.css">
</head>

<div align='center'><table width='80%'><tr><td>

<body>

<?php

$search = $_GET['search'];

$home = "search_instances.php";
   
echo "<div align='center'><form action='$home?search=$search' method='GET'>
     <input type='text' name='search' placeholder='Category'>
     <input type='submit' style='background-color:#AE0EEE;color: #EEEEEE;' value='  Search  '> 
     </form></div>";

   include("sql_conf.php");

   if($_GET['search']){
   
   $query = "SELECT * FROM instances WHERE categories LIKE '%$search%'";

   $result = mysqli_query($db, $query);
 
   while ($row = mysqli_fetch_array($result)){

       $name = $row['0'];
       $url = $row['1'];
       $categories = $row['2'];
      
       echo "<h1>$name</h1>  <a href='$url' target='_blank'>$url</a>  <i>$categories</i><hr></hr></br>";
   }


}

?>

</td></tr></table></div>

</body>

</html>
