<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Rank</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<div align='center'>

<?php

    $user = $_SESSION['user'];

    $file = $_GET['file'];

    include("sql_conf.php"); 


    // In files table count the total number of likes of each user

    //$query = "SELECT * FROM files GROUP BY coins HAVING COUNT(coins) > 0 ORDER BY coins DESC LIMIT 0, 1000";

    
     
    // In coins table count the numbers of coins of the file

    $query = "SELECT * FROM files";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){

           $total_coins+= $row['4'];     	

        }

    //echo "$total_coins";

    //die;

    
    $query = "SELECT name, coins, views, likes, (coins+(likes/100)+(views/1000)) as Total FROM files GROUP BY coins HAVING COUNT(coins) > 0 ORDER BY Total DESC LIMIT 0, 1000";



    $result = mysqli_query($db, $query);

    echo "</br> General Data: <h2>$total_coins coins fund</h2> </br></br><table width='80%' style='border: 1px solid #EEE;'><tr><td>File</td><td>Coins</td><td>Views</td><td> Likes </td> <td> Total</td></tr>";
	
        while ($row = mysqli_fetch_array($result)){

            $name = $row['0'];  
            $coins = $row['1'];  
            $views = $row['2']; 
            $likes = $row['3'];               
            $g = $row['4'];                
            $h = $total_coins / $g;     

            $total_asset+= $row['4'];

            echo "<tr><td><a href='views.php?file=$name' target='_blank'>$name</a></td><td>$coins</td><td>$views</td><td>$likes</td> <td> $g </td></tr>";   	
        }

    echo "</table>";

    echo "</br>";

    echo "Coins amount: $total_coins </br>";
    echo "File value amount: $total_asset </br>";

    echo "Coins absolute value: ";
    echo $cash_value = $total_coins / $total_asset;

    $value_cut = substr($cash_value, 0, 4);

    echo "</br>$value_cut <u> is the current value of each coin</u></br>";

    echo date('c');

    //echo $cash_value = number_format((float)$cash_value, 2, '.', ''); 

    $final_balance = $user_coins * $value_cut;
 	
    //echo "</br>your balance is: " . $user_coins . " x " . $value_cut . " = <h1>" . $final_balance . "</h1>"; 

?>

</div>



</body>

</html>
