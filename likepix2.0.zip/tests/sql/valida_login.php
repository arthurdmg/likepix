<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

$user = $_POST['username'];
$pass = $_POST['password'];

    if ($user == "" or $pass == ""){
	echo "Blank fields!"; die;
    }	

    if( $_SESSION['captcha'] == $_POST['captcha']){ 
	
	include("sql_conf.php");



        $query = "SELECT * FROM users WHERE user LIKE '$user'";


        $result = mysqli_query($db, $query);

            while ($row = mysqli_fetch_array($result)){
                $user_db = $row['0'];
                $pass_db = $row['1'];
            }	

            if ($user == $user_db and $pass == $pass_db){
            
                echo "<h1><a href='../index.php'>Continue</a></h1>";    
                $_SESSION['user'] = $user;
                } else {
                echo "Wrong username or password!";
            }

    }else{
        echo "<h1>Wrong captcha</h1>";
    }

?>

</body>

</html>
