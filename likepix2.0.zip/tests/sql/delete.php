<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Delete</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

    $file = $_GET['file'];	
	
    echo "<h1>Delete '$file' from your account?</h1>";

    $confirm = $_GET['confirm'];

if ($confirm){

    include("sql_conf.php"); 

    $query = "DELETE FROM files WHERE user='$user' and name='$file'";

    $result = mysqli_query($db, $query);

    $query = "DELETE FROM comments WHERE file='$file'";

    $result = mysqli_query($db, $query);

    $query = "DELETE FROM likes WHERE file='$file'";

    $result = mysqli_query($db, $query);

    echo "Deleted!</br> <a href='../index.php'>back</a>";

} else { 

    echo "<a href='delete.php?confirm=1&file=$file'>Yes</a> / <a href='comment.php?file=$file'>No</a>";
   
}

?>

</body>

</html>
