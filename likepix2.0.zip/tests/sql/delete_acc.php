<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];
    
    if ($user == ""){echo "<a href='login.php'>Please log-in!</a>"; die;}
	
    echo "<h1>Delete all items and your account?</h1>";

    $confirm = $_GET['confirm'];   

if ($confirm){

    $user = $_SESSION['user'];  

    include("sql_conf.php"); 

    $query = "DELETE FROM files WHERE user LIKE '$user'";

    $result = mysqli_query($db, $query);

    $query = "DELETE FROM likes WHERE user LIKE '$user'";

    $result = mysqli_query($db, $query);

    $query = "DELETE FROM comments WHERE user LIKE '$user'";

    $result = mysqli_query($db, $query);

    $query = "DELETE FROM users WHERE user LIKE '$user'";

    $result = mysqli_query($db, $query);

    echo "Account clear! <a href='../index.php'>back</a>";

} else { 

    echo "<a href='delete_acc.php?confirm=1'>Yes</a> / <a href='../index.php'>No</a>";
   
}

?>

</body>

</html>
