<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Comment</title>
<link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

    $file = $_GET['file'];

    $ext = explode(".", $file);

    $ext = $ext[1];
 
    if($ext == 'jpg'){

    $show = "<a href='../categories/$file'><img src='../categories/$file' width='100%'></a>";

    }else{
    
    $show = "<a href='../categories/$file'><video controls src='../categories/$file' width='100%'></a>";
  
    }

    $comment = $_POST['comment'];

    echo "<div align='center'><table width='100%'style='background-color: #EEE; border-radius: 1%; padding:2%;'><tr><td width='50%' valign='top'>
    <div align='center'>";

    echo $show;

    if ($user == $_SESSION['user']){$delete = "<a href='delete.php?file=$file'><img src='../icons/cancel.png'>";}else{$delete = "";}

    echo $file . "</td><td valign='top' style='padding:2%;'>";
  
    include("sql_conf.php");
    
    $chars = array ('<', '>', "'", '"', '$', '=', '*');

    $query = "SELECT * FROM files WHERE name LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
        }



    //if ($file_db == ""){die;}
    if (!file_exists("../categories/$file")){die;}

    if($comment and $user){


        $query = "SELECT * FROM comments WHERE file LIKE '$file' and user LIKE '$user'";


        $result = mysqli_query($db, $query);

            while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $user_db = $row['1'];
            }	


	    if ($file_db != "" and $user_db != ""){echo "<b>Already commented!</b></br>";} else {

                $day = date("d");

                $month = date("m");

                $year = date("y");



                $hour = date('G');
                $min = date('i');
                $sec = date('s');    

                $date = $day . '/' . $month . '/' . $year . ' [' . $hour . ':' . $min . ':' . $sec . ']';

      	        $comment = str_replace($chars,"", $comment);


                $query = "INSERT INTO comments (file, user, comment) VALUES ('$file', '$user', '$date : $comment')";


                mysqli_query($db, $query);

                echo "<u>Comment done!</u></br>";

   	    }

    }

    if(!$user){echo "&nbsp;<a href='login.php'>Please log-in!</a></br>";}else{echo "&nbsp;<a href='delete_comment.php?file=$file'>Delete my comment <img src='../icons/cancel.png'></a></br></br>";}
	    	
    $query = "SELECT * FROM comments WHERE file LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
    
            $user_db = $row['1'];
            $comment_db = $row['2'];

  	    echo "$user_db : $comment_db </br><hr></hr>"; 
	}

    echo "<form method='POST' action='comment.php?file=$file'>
    <input type='text' name='comment' maxlength='200'>    <input type='submit' value=' Comment ' />
    </form></div>";


?>
</tr></td></table></div>

</body>

</html>
