<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Rank</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<div align='center'>

<?php

    $user = $_SESSION['user'];

    $file = $_GET['file'];

    include("sql_conf.php"); 


    // In files table count the total number of likes of each user

    $query = "SELECT user, SUM(likes), COUNT(likes) FROM files GROUP BY user HAVING COUNT(likes) > 0 ORDER BY SUM(likes) DESC LIMIT 0, 1000";


    $result = mysqli_query($db, $query);

    echo "Total likes per user:</br></br><table width='80%'><tr><td>User</td><td>Total Likes</td><td>Total Posts</td></tr>";
	
        while ($row = mysqli_fetch_array($result)){

            $users = $row['0'];  
            $likes = $row['1'];  
            $files = $row['2']; 
            
            echo "<tr><td><a href='../index.php?user=on&search=$users' target='_blank'>$users</a></td><td>$likes</td><td>$files</td></tr>";   	
        }

    echo "</table>";
 	

?>

</div>

</body>

</html>
