<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Delete</title>
  <link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    $user = $_SESSION['user'];

    $file = $_GET['file'];	
	
    echo "<h1>Delete your comment on '$file'?</h1>";

    $confirm = $_GET['confirm'];

if ($confirm){

    include("sql_conf.php"); 

    $query = "DELETE FROM comments WHERE user='$user' and file='$file'";

    $result = mysqli_query($db, $query);

    echo "Deleted!</br> <a href='comment.php?file=$file'>back</a>";

} else { 

    echo "<a href='delete_comment.php?confirm=1&file=$file'>Yes</a> / <a href='comment.php?file=$file'>No</a>";
   
}


include("ads.php");

?>

</body>

</html>
