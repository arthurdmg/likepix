<?php error_reporting(0); session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Views</title>
<link rel="stylesheet" href="../default.css">
</head>

<body>

<?php

    function ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

    $user = ip();

    $file = $_GET['file'];

    $ext = explode(".", $file);

    $ext = $ext[1];
 
    if($ext == 'jpg'){

    $show = "<a href='../categories/$file'><img src='../categories/$file' width='100%'></a>";

    }else{
    
    $show = "<a href='../categories/$file'><video controls src='../categories/$file' width='100%'></a>";
  
    }

    echo "<div align='center'><table><tr><td>";
    echo $show;
    echo "</td></tr></table></div>"; 

    include("sql_conf.php"); 

    // Check if file exists
    if (!file_exists("../categories/$file")){echo "File not found!"; die;}
    if (!$file){echo "File not found!"; die;}

    // Check if file exists in DB 	
    $query = "SELECT * FROM files WHERE name LIKE '$file'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $file_views_db = $row['5'];
        }


    if ($file_db == ""){

    $query = "INSERT INTO files (name) VALUES ('$file')";
    $result = mysqli_query($db, $query);
     
    }    


    echo "<div align='center'> 	Total views : " . $file_views_db . "</div>";

    // In views table search for the user and file liked

    $query = "SELECT * FROM views WHERE file LIKE '$file' and user LIKE '$user'";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){
                $file_db = $row['0'];
                $user_db = $row['1'];
        }	


    if ($file_db != "" and $user_db != ""){die;} else{

	// In likes table insert user and file if not voted



        $query = "INSERT INTO views (file, user) VALUES ('$file', '$user')";


        mysqli_query($db, $query);

        //echo "Viewed!";
	
    }

    // In views table count the numbers of views of the file

    $query = "SELECT file, COUNT(file) FROM views WHERE file LIKE '$file' GROUP BY file HAVING COUNT(file) > 0";


    $result = mysqli_query($db, $query);

        while ($row = mysqli_fetch_array($result)){

            $views = $row['1'];     	
        }

    // Update the likes number in the file table


    $query = "UPDATE files SET views = '$views' WHERE name = '$file'";


    $result = mysqli_query($db, $query);   

    echo "<div align='center'>$views</div>";

    include("ads.php");
   
?>