<table width='100%'>
  <tr>
    <td width='50%' valign='top'>
   
    <?php
    $limit = 100;
    $pic = rand(1, $limit);

    echo "<a href='H/$pic.jpg' target='_blank'><img src='H/$pic.jpg' width='100%'></a>";
    ?>
 
    </td>
    <td valign='top'>

    <?php
    $limit = 100;
    $pic = rand(1, $limit);

    echo "<a href='W/$pic.jpg' target='_blank'><img src='W/$pic.jpg' width='100%'></a><br>";

    $pic = rand(1, $limit);

    echo "<a href='W/$pic.jpg' target='_blank'><img src='W/$pic.jpg' width='50%'></a>";

    $pic = rand(1, $limit);

    echo "<a href='W/$pic.jpg' target='_blank'><img src='W/$pic.jpg' width='50%'></a><br>";

    $pic = rand(1, $limit);

    echo "<a href='W/$pic.jpg' target='_blank'><img src='W/$pic.jpg' width='50%'></a>";

    $pic = rand(1, $limit);

    echo "<a href='W/$pic.jpg' target='_blank'><img src='W/$pic.jpg' width='50%'></a><br>";
    ?>

    </td>
  </tr>
</table>
