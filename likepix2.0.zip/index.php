﻿<?php error_reporting(0); session_start(); if($_GET['lang'] != "") {$_SESSION['langs'] = $_GET['lang'];} $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      Home
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/sourcecode/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Liked!");
    }
  </script>


  <style type="text/css">   
    body{

      font-family: Arial;
      color: #666666;
    }
 
    input{

      border: 2px solid #aaa;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    select{

      border: 2px solid #aaa;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

      padding: 10px;
      text-decoration: none;
    }

    a:hover{

      background-color: #DDD;
    }


  </style>

  <body>
    <div align='center'>
    <form action="index.php" method="POST">
     <a href='sourcecode.zip' style='color: #FFA500;'>Sourcecode</a>
     <a href='Indexer.php'>Indexer</a>
     <a href='index.php?lang=eng'>Eng</a> <a href='index.php?lang=pt-br'>Pt-br</a>          
     <?php echo $lbl_option_get; ?>
     <a href='categories.php'><?php echo $lbl_u_categories; ?></a>

     <a href='download.php'>Feed</a>
     <a href='all_files.php'>Files</a>   
     <a href='paste.php'>Paste</a>  
     <a href='index.php'>Home</a>

     <input type="text" placeholder="<?php echo $lbl_name; ?>" name="search">    
     <input type="text" placeholder="<?php echo $lbl_category; ?>" name="category">   

     <?php

     echo "<select name='filetype'>";
     
     foreach (glob("categories/*") as $file_type_path){

         $file_type = explode('/', $file_type_path);
         $file_type = $file_type[1];

         if ($file_type == "thumbs" || $file_type == "files" || $file_type == "html"){continue;}

         echo "<option value='$file_type'>$file_type</option>";
  
     }
   
     
     echo "</select>";
 
     ?>

     <input type="submit" value="<?php echo $lbl_search; ?>" />   

     &nbsp; &nbsp;  

     <a href='#' style='padding: 0px;' OnClick="alert('');"><img src='logos/BTC.png' height='25px'></a> &nbsp;  
     <a href='#' style='padding: 0px;' OnClick="alert('');"><img src='logos/ETH.png' height='25px'></a> &nbsp;   

   </form>
  </div>
  <hr style='color: #EEE;'></hr>

<?php


if(!file_exists("fileinfo")){

    mkdir("fileinfo");
}


if(!file_exists("categories")){

    mkdir("categories");
}

if(!file_exists("categories/thumbs")){

    mkdir("categories/thumbs");
}

if(!file_exists("categories/files")){

    mkdir("categories/files");
}


$start = $_GET['start'];  

$category = $_POST['category']; 
if ($category == ""){$category = $_GET['category'];}
	
if (!$start){$start = 0;}

$c = 0;
$limit = 18;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;
$collum = 0;

$search = $_POST['search'];
$search = strtolower($search);
$search = str_replace(" ", "_", $search); 

$filetype = $_POST['filetype']; 
if ($filetype == ""){$filetype = $_GET['filetype'];}

$slash_break = 3;

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

echo "<div align='center'><table>";

if ($search != ""){

    if ($filetype == ""){
        
        $filetype = "mp4";

    }

    if ($category == ""){
        
        $files_path = "categories/$filetype/files";

    }else{

        $files_path = "categories/$filetype/$category";
    }

    foreach (glob("$files_path/*") as $picture){
   

        $item = explode('/', $picture);

        $picture_lowercase = strtolower($item[$slash_break]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($item[$slash_break]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $thumb_dir = '';

                $item = $item[$slash_break];

                $file_ext = substr($item, -3);
                $file_ext = strtolower($file_ext);

                if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){

                    $thumb_dir = $picture;
                } 

                if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                    $thumb_dir = 'img/nopic.jpg';
                }        

                if(file_exists("categories/$filetype/thumbs/" . $item . '.jpg')){

                    $thumb_dir = "categories/$filetype/thumbs/" . $item . '.jpg';
                }   
 
                $item_len = strlen($item);
                if ($item_len > 20){$item = substr($item, 0, 20) . "...";} 
 
                if($collum == 0){echo "<tr>";}

                echo "<td><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' height='200px'></a><br><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a><br><br></td>";
      
                $collum++;  

                if($collum == 3){echo "</tr>"; $collum = 0;}

                $search_break++;      
            }

        $entry++;
        if($search_break == $limit){break;}
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>$lbl_no_results</h1><br><i>You can use the section of no results to include an advertisement page</div>";}

}else{

    if ($filetype == ""){
        
        $filetype = "mp4";
    }


    if ($category == ""){
        
        $files_path = "categories/$filetype/files";

    }else{

        $files_path = "categories/$filetype/$category";
    }

    foreach (glob("$files_path/*") as $picture){
    

        if ($c >= $ini and $c < $end){

            $thumb_dir = '';
            $file_ext = '';
            $item = '';

            $item = explode('/', $picture);
            $item = $item[$slash_break];

            $file_ext = substr($item, -3);
            $file_ext = strtolower($file_ext);

            if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){

                $thumb_dir = $picture;
            } 

            if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                $thumb_dir = 'img/nopic.jpg';

            }        

           if(file_exists("categories/$filetype/thumbs/" . $item . '.jpg')){

               $thumb_dir = "categories/$filetype/thumbs/" . $item . '.jpg';
 
           }     


           $item_len = strlen($item);

           if ($item_len > 20){$item = substr($item, 0, 20) . "...";}           
 
           if($collum == 0){echo "<tr>";}

           echo "<td><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' height='200px'></a><br><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a><br><br></td>";
      
           $collum++;  

           if($collum == 3){echo "</tr>"; $collum = 0;}

           $search_break++;         
           
       }    

    $c++;

    if($search_break == $limit){break;}

     }

    if ($search_break == 0){

        echo "<div align='center'><br><i>You can use this section to include an advertisement page<br> </i><h1><i>Sites can copy contents each other easily</i></h1><br>
        <li>Each site provides a list of all files hosted. By default the page name for access this function is <b>all_files</b> or <b>allFiles</b><br>(eg: all_files.php, http://example.com/allfiles).</li><br>
        <li>Each site provides a page that retrieves the path of a file when a ID is inserted via GET . By default the page name is <b>download</b> <br> (eg: the input http://example/download.php?id=0 shows the path of file with 0 ID as http://example/files/creative-commons-rock.mp3).</li> <br>
        <li>A site can copy or backup contents each other even using different programming languages</li><br>
  
        <br><h1><i>Quick guide</i></h1>
        <table width='60%'><tr><td>
        <li> When you upload a file is created a category with the file extension type.</li>
        <li> You can search the files of an extension without fill the <i>category</i> or <i>name</i> fields</li>
        <li> Insert your hostname in <i>config.php</i></li>
        <li> <b>Feed</b>: You can download the contents of a site (don't test in localhost, test using a free host or from web)</i></li>
        <li> If you want uses only a subdirectory you can replace <i>index.php</i> and the others scripts by the version with '_simple.php' ending (in the <i>simple</i> folder)</li>
        <li> If a file was uploaded without a category it will be sent to the default category 'files'</li>  
        <li>No MySQL required</li>   
        </td></tr></table> 
    ";

    }
       
}
echo "</table></div>"; 
?>

<?php
echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category&filetype=$filetype'>$i</a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category&filetype=$filetype'>$i</a>";
    }

} 

echo "</div>";

?>

    <div align='center'><br>
      <a href='index.php?category=quickguide' style='text-decoration: none; color: #666666;' OnClick="alert('The site is ​​not responsible for the files uploaded by the users or hosted by third parties.');">Terms of use</a></a>
    </div>
    <div id='ifrm'>

  </body>
</html>