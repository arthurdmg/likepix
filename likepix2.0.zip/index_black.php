﻿<?php error_reporting(0); session_start(); if($_GET['lang'] != "") {$_SESSION['langs'] = $_GET['lang'];} $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      Home
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/sourcecode/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Liked!");
    }
  </script>

  <style type="text/css">  

     .description{
       color: #DDD;
       font-family: arial;
       letter-spacing: 8px;
       text-justify: justify;
     }

     a{
       color: #666666;
       text-decoration: none;
     }

     .aPanel{
       color: #ffff;
       text-decoration: none;
     }

     body{
       color: #EEE;
       font-family: arial;
       letter-spacing: 2px;
       background-color: #333;
     }

    .panelMain{ 
       padding: 5px;
     }
   
    .panel{ 
      background-color: #DDD;    
      border: 2px solid #999;
      border-radius: 5px 5px 5px 5px;
      padding: 4%;
    }

    .panelSub{ 
      background-color: #666;    
      border: 2px solid #999;
      border-radius: 3px 3px 3px 3px;
    } 

    .panelSub:hover{ 
      background-color: #999;    
      border: 2px solid #999;
      border-radius: 3px 3px 3px 3px;
    }

    .panelSub2{ 
      background-color: #999;    
      border: 2px solid #999;
      border-radius: 3px 3px 3px 3px;
    } 

    input{
      padding: 4%;
      width: 100%;
      border: 2px solid #999;
      border-radius: 5px 5px 5px 5px;
    }

    .big{
      background-color: #333;
      margin-top: 10%;
      padding-top: 2%;
      padding-bottom: 2%;
      padding-left: 20%;
      padding-rigHt: 20%;
      border-radius: 3px 3px 3px 3px;
    }

    .small{
      font-size: 10px;
    }

   .big:hover{
      background-color: #999;  
    }

  </style>

  <body>

<table width='100%' class='panelMain'><tr><td width='25%' valign='top'>

    <table width='100%'>
      <tr>
        <td  class='panelSub'>
          <br><br><br><br>         
          <div align='center'>Advertise here                  
          </div>
          <br><br><br><br>  
        </td>
      </tr>
    </table>
    </br>

    <table width='100%'>
      <tr>
        <td  class='panelSub2'>
          <br>        
          <div align='center'><a href='sourcecode.zip' target='_blank' class='aPanel'>Sourcecode</a></div>
          <br> 
        </td>
      </tr>
    </table>

    <table width='100%'>
      <tr>
        <td  class='panelSub'>
          <br>        
          <div align='center'><a href='upload.php' class='aPanel'>Upload</a>
          </div>
          <br> 
        </td>
      </tr>
    </table>

<form action='<?php echo "index_black.php?&category=" . $_GET['category']; ?>' method="POST"> 

<input type="text" placeholder="<?php echo $lbl_name; ?>" name="search">    
<input type="text" placeholder="<?php echo $lbl_category; ?>" name="category" value="<?php echo $_GET['category']; ?>">  

<input type="submit" value="<?php echo $lbl_search; ?>" />


</form>

<a href='index_black.php'>Home</a>  
<a href='#' OnClick="alert('The site is ​​not responsible for the files uploaded by the users or hosted by third parties.');">Terms of use</a>
<a href='categories.php'>Categories</a>
<a href='download.php'>Feed</a> <a href='#' style='text-decoration: none; color: #666666;' OnClick="alert('The feed permits copy the contents from one site to another. That is, all contents of a site is copied if host the same scripts.');">[?]</a>
<a href='all_files.php' target='_blank'>Files</a>
<a href='index_basic.php' target='_blank'>Simplified</a>
<a href='indexer_search.php' target='_blank'>Indexer</a>
</td><td width='60%' valign='top' >      

    <table width='100%' class='panel'>
      <tr>
        <td>        
   
<?php

if(!file_exists("categories")){

    mkdir("categories");
}

if(!file_exists("categories/thumbs")){

    mkdir("categories/thumbs");
}

if(!file_exists("categories/files")){

    mkdir("categories/files");
}


$start = $_GET['start'];  

$category = $_POST['category']; 
if ($category == ""){$category = $_GET['category'];}
	
if (!$start){$start = 0;}

$c = 0;
$limit = 20;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];
$search = strtolower($search);
$search = str_replace(" ", "_", $search); 

$slash_break = 2;

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

if ($search != ""){

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        $item = explode('/', $picture);

        $picture_lowercase = strtolower($item[$slash_break]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($item[$slash_break]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $thumb_dir = '';

                $item = $item[$slash_break];

                $item_len = strlen($item);

                if ($item_len > 40){$item = substr($item, 0, 40) . "...";}
 
                echo "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u> </a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a></i>" . "&nbsp; <a href='$picture' target='_blank'>$item</a><hr></hr>";
                $search_break++;   
            }

        $entry++;
        if($search_break == $limit){break;}
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>$lbl_no_results</h1></div>";}

}else{

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        if ($c >= $ini and $c < $end){
 
            $thumb_dir = '';

            $item = explode('/', $picture);
            $item = $item[$slash_break];

            $item_len = strlen($item);

            if ($item_len > 40){$item = substr($item, 0, 40) . "...";}

            echo "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u> </a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a></i>" . "&nbsp; <a href='$picture' target='_blank'>$item</a><hr></hr>";
            $search_break++;             
        }

    $c++;
    if($search_break == $limit){break;}
    }

}

$i = $start +1;

if ($search_break==0) {
    $results_btn = "<div align='center'><h1>No more results!</h1><br><br><a href='index_black.php?start=0&search=$search&category=$category' class='big' width='100%'>Refresh</a></div><br>";
} else {
    $results_btn = "<br><br><div align='center'> <a href='index_black.php?start=$i&search=$search&category=$category' class='big' width='100%'>More results</a></div><br>";

}

echo "$results_btn";


?>

        </td>
      </tr>
    </table>
</tr>
</table>

<br>

<div align='center'>

 <br><br>


 <a href='#'>Top</a>
<a href='' target='_blank'><img src=''></a>

</div>

    <div id='ifrm'>

  </body>
</html>