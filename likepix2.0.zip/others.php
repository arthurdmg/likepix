﻿<a href='paste.php' target='_blank'>Paste</a><br>
<a href='indexer.php' target='_blank'>Indexer</a><br>