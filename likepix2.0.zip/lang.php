﻿<?php if ($lang == "pt-br"){
    $lbl_option_get = "<a href='upload.php?lang=pt-br'>Upload</a>";
    $lbl_upload = "Upload";
    $lbl_categories = "categorias";
    $lbl_category = "categoria";
    $lbl_comments = "Comentários";
    $lbl_tittle = "Título";
    $lbl_select_file = "Selecionar arquivo";
    $lbl_select_thumb = "Selecionar thumbnail";
    $lbl_u_category = "Categoria";
    $lbl_u_categories = "Categorias";
    $lbl_pix_key = "PayPal/ Pix";
    $lbl_or_link = "ou enviar link";
    $lbl_send_your_file = "Enviar seu arquivo ou link";
    $lbl_search = "Pesquisar";
    $lbl_like = "Curtir";
    $lbl_comment = "Comentar";
    $lbl_send_comment = "Enviar comentário";
    $lbl_back = "Voltar";
    $lbl_voted = "Votado com sucesso!";
    $lbl_name = "nome";
    $lbl_no_results = "Nenhum resultado encontrado!";
    $lbl_send = "Enviar";
    $lbl_thumb_info= "O thumbnail é a imagem, capa ou ilustração do seu arquivo. Deve ser no formato .jpg";
    $lbl_sent = "- Arquivo enviado com sucesso!<br>";
    $lbl_error = "Alguns erros foram detectados!<br><br>- Já existe um arquivo com esse nome. (Tente enviar com um nome diferente).<br>";
    $lbl_error_thumb = "- Formato de thumbail não permitido!<br>";
    $lbl_sent_thumbnail = "- Thumbnail enviado com sucesso!<br>";
    $lbl_sent_link = "- Link enviado com sucesso!<br>";
    $lbl_sourcecode = "código-fonte";
    $lbl_simple_indexer = "Indexador simples";
    $lbl_name = "Nome";
    $lbl_Description = "Descrição";
}

if ($lang == "eng" or $lang == ""){
    $lbl_option_get = "<a href='upload.php?lang=eng'>Upload</a>";
    $lbl_upload = "Upload";
    $lbl_categories = "categories";
    $lbl_category = "category";
    $lbl_comments = "Comments";
    $lbl_tittle = "Tittle";
    $lbl_select_file = "Select file";
    $lbl_select_thumb = "Select thumbnail";
    $lbl_u_category = "Category";
    $lbl_u_categories = "Categories";
    $lbl_pix_key = "PIX/ PayPal";
    $lbl_or_link = "or send a link";
    $lbl_send_your_file = "Send your file or link";
    $lbl_search = "Search";
    $lbl_like = "Like";
    $lbl_comment = "Comment";
    $lbl_send_comment = "Send comment";
    $lbl_back = "Back";
    $lbl_voted = "Liked!";
    $lbl_name = "name";
    $lbl_no_results = "No results!";
    $lbl_send = "Send";
    $lbl_thumb_info= "The thumbnail is the cover or screenshot of your file. Must be in .jpg format";
    $lbl_sent = "- File sent with success!<br>";
    $lbl_error = "Some errors detected!<br><br>- Already exists a file with this name. (try with a different name).<br>";
    $lbl_error_thumb = "- Wrong thumbnail format!<br>";
    $lbl_sent_thumbnail = "- Thumbnail sent with success!<br>";
    $lbl_sent_link = "- Link sent with success!<br>";
    $lbl_sourcecode = "source code";
    $lbl_simple_indexer = "Simple page indexer";
    $lbl_name = "Name";
    $lbl_Description = "Description";
}

?>