﻿<?php error_reporting(0); 

include("config.php");

$id = $_GET['id'];  

$category = $_GET['category'];
	
if (!$id){$id = 0;}

$c = 0;

if ($category == ""){

    foreach (glob("categories/*") as $categories){


        foreach (glob("$categories/*") as $files){


            if ($c == $id){

                echo $hostname . $files;
    
            }

        $c++;
        }

    }

}else{

    foreach (glob("categories/$category/*") as $files){


        if ($c == $id){
            echo $hostname . $files;    
        }

    $c++;
    }
}


?>