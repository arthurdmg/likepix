﻿<?php error_reporting(0); session_start(); $lang = $_SESSION['langs']; if($_GET['lang'] != ""){$lang = $_GET['lang'];} include("lang.php");?>

<html>
  <style type="text/css">

    input{
    
      border: 1px solid #AAA;
      border-radius: 2px 2Px 2px 2px;
      padding: 10px;
      margin: 1px;
    }

     body{
       color: #666;
       font-family: arial;
       letter-spacing: 2px;   
     }

    a{
      color: #666;
    }


  </style>

  <body>
    <div align='center'>
      <form enctype="multipart/form-data" action="upload.php" method="POST">

        <table width='80%' style="border: 1px solid #CCCCCC; padding: 20px; background-color: #CCCCCC;">        
          <tr>
            <td><div style='color: #999;'><?php echo $lbl_send_your_file; ?></div></td>
          </tr>
        </table>

        <table width='80%' style="border: 1px solid #CCCCCC; border-radius: 2px 2px 2px 2px; padding: 20px; background-color: #FFF;">
          <tr>
            <td><?php echo $lbl_tittle; ?></td>
            <td><input name="name" type="text" /></td>    
          </tr>
          <tr>
            <td><?php echo $lbl_select_file; ?></td>
            <td><input name="file" type="file" /> <?php echo $lbl_or_link; ?> <input name="links" type="text" /></td>
          </tr>
          <tr>        
            <td><?php echo $lbl_select_thumb; ?></td>
            <td><input name="thumb" type="file"/> <a href='#' OnClick="alert('<?php echo $lbl_thumb_info ?>');">[?]</a>        
          </tr>
          <tr>
            <td><?php echo $lbl_u_category; ?></td>
            <td><input name="category" type="text" /></td>  
          </tr>
          <tr>
            <td><?php echo $lbl_pix_key; ?></td>
            <td><input name="pix" type="text" /></td>  
            <td><input type="submit" name="upload" value="<?php echo $lbl_send; ?>" /></td>
          </tr>
        </table>
      </form>
    <a href='index.php'><?php echo $lbl_back; ?></a>
  </div>

<?php

$name = $_POST['name'];

$link = $_POST['links'];

$category = $_POST['category'];

$avoid_chars = array ('<', '>', '//', '.');

$name = str_replace($avoid_chars, "", $name); 

// Files with space in the name can cause error when try download it
$name = str_replace(" ", "_", $name); 

$category = str_replace($avoid_chars, "", $category); 

$avoid_chars_link = array ('<', '>');

$link = str_replace($avoid_chars_link, "", $link); 

$file_ext = strtolower(pathinfo(basename($_FILES["file"]["name"]),PATHINFO_EXTENSION));

if($file_ext == ""){$file_ext = "html";}

if(!file_exists(categories/$file_ext/thumbs)){
    mkdir("categories/$file_ext/thumbs");
}

if(!file_exists(categories/$file_ext/files)){
    mkdir("categories/$file_ext/files");
}

if($category != ""){

    mkdir("categories/$file_ext/$category");
    $category_path = "categories/$file_ext/$category/";

}else{

   $category_path = "categories/$file_ext/files/";
   $category = "$file_ext/files";

}



$file = basename($_FILES["file"]["name"]);

$target_file = $category_path . $file;

$image_type = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if($name != ""){$target_file = $category_path . $name . '.' . $image_type;}

$allow_upload = 1;

$msg_error = "";

if($image_type == "php") {
    $allow_upload = 0;
}

if(file_exists($target_file)){
    $msg_error = $msg_error .  $lbl_error;
    $allow_upload = 0;
}

if($allow_upload){

    if(!file_exists(categories/$file_ext)){
        mkdir("categories/$file_ext");
    }

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "$lbl_sent";
        $sent_file = 1;
    } else {
        $allow_upload = 0;
        echo $msg_error;
    }
}

if($_POST['upload']){
    echo $msg_error;
} 

$target_dir = "categories/thumbs/";

$target_file = $target_dir . basename($_FILES["file"]["name"]);

$image_type = strtolower(pathinfo(basename($_FILES["thumb"]["name"]),PATHINFO_EXTENSION));

$allow_upload2 = 1;

if($name != ""){$target_file = $target_dir. $name . '.' . $file_ext;

    $check_thumb = "categories/thumbs/$name" . "." . $file_ext . ".jpg" ;

    if(file_exists($check_thumb)){
        $msg_error = $msg_error . $lbl_error;
        $allow_upload2 = 0;
    }
}

if($image_type != "jpg") {
    $msg_error = $msg_error . $lbl_error_thumb; 
    $allow_upload2 = 0;
}

if(file_exists($target_file)){
    $msg_error = $msg_error . $lbl_error;
    $allow_upload2 = 0;
}

if($allow_upload && $allow_upload2){
    if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $target_file . "." . $image_type)) {
        echo "$lbl_sent_thumbnail";
        $sent_file = 1;
    } else {
    
        echo $msg_error;
    }
}

if($name != "" && $link != "" && $allow_upload2){
    if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $target_dir . $name  . '.html' . '.jpg')) {
        echo $lbl_sent_thumbnail;
        $sent_file = 1;
    } else {
    
        echo $msg_error;
    }
}

$link_dir = "categories/$category/$name";

$ads = 1;

if($ads){
    $ads = "<iframe src='../../ads.php' width='100%' height='80%'></iframe><br>";
}else{
    $ads = "";
}

if(!file_exists("categories/$category/$name.html") && basename($_FILES["file"]["name"]) == ""){
 
    mkdir("categories/$category");
    $write = fopen("categories/$category/$name.html", "w");
    fwrite($write, "$ads<a href='$link'>Continue</a>");
    fclose($write);
    echo "$lbl_sent_link";
    $sent_file = 1;
}

$log = 1;

if ($sent_file == 1 && $log){
    
    $date = date("Ymd");
       
    $pix = $_POST['pix'];
    $pix = str_replace($avoid_chars_link , "", $pix); 

    $file = basename($_FILES["file"]["name"]);

    if($name == ""){$filename = $file;}else{
        $filename = $name . '.' . $file_ext;
    }

    if($name != "" and $link != ""){
        $filename = $name . ".html";
    }

    $hash_name = sha1($category_path . $filename);

    if(!file_exists("fileinfo/$hash_name")){

        $write = fopen("fileinfo/$hash_name", "a");
        fwrite($write, "$name,$link,$file,$category,$pix,$date");
        fclose($write);
    }
}      


?>