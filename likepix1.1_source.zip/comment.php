﻿<?php error_reporting(0); session_start(); $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      <?php echo $lbl_comments; ?>
    </title>
  <link rel="icon" href="img/logo_1.png">

  </head>

  <style type="text/css">
  
    body{

      font-family: Courier;
    }

    a{

      color:#00FF00;      
    }

    i{

      color:#AAAAAA;
      text-decoration: none;
    }

  </style>

  <body>

    <div align='center'>

      <table width='80%' style='background-color: #CCCCCC;'>
        <tr>
          <td width='12%'>
            <a href='index.php'><img src='img/01.png' width='90%'></a>        
          </td>
          <td>         
         
          </td>
        </tr>
      </table>

    <table width='80%'  style="border: 1px solid #CCCCCC; padding: 20px;">
      <tr>
        <td> 
    
<?php

$thumb_check = explode('/',  $_GET['comment_file']);

$thumb_dir = $thumb_check[2];

if(!file_exists("categories/thumbs/$thumb_dir.jpg")){

    $file_ext = substr($_GET['comment_file'], -3);
    $file_ext = strtolower($file_ext);

    if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){

    $thumb_dir = $_GET['comment_file'];

    } else {   
 
    $thumb_dir = 'img/nopic.jpg';

    }

    echo "<div align='center'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='25%'></a></div>";

}else{
              
    $thumb_dir = "categories/thumbs/$thumb_dir.jpg";
    echo "<div align='center'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='25%'></a></div>";

}


?>

<?php

function ip() {

    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

if(file_exists($_GET['comment_file'])){

    if(!file_exists("hashes")){

        mkdir("hashes");
    }

    $message = $_POST['message'];

    $comment_file = $_GET['comment_file'];

    $avoid_chars = array ('<', '>', "//");

    $message = str_replace($avoid_chars, "", $message); 

    $filesize = filesize("$comment_file.txt");

    if ($filesize > 5000){unlink("$comment_file.txt");}  

    echo "<form action='comment.php?comment_file=$comment_file' method='POST'>
      <br>
<div align='center'>
     $lbl_send_comment <input type='text' name='message' maxlength='50'>
     
     <input type='submit' name='submit_comment' value='$lbl_send' style='background-color: #EEEEEE;'>
</div>
     </form><br>";

    $ip = ip();

    $ip_hash = sha1($ip);

    $ip_nick = preg_replace('/(.)\1+/', '$1', $ip_hash);

    $comment_file = 'hashes/' . sha1($comment_file);

    echo "<div align='left'>";
    
    include("$comment_file" . ".txt"); 
    
    echo "</div>";

    $day = date("d");

    $month = date("m");

    $year = date("y");




    $date = $day . '/' . $month . '/' . $year;

    if ($message != ''){
        $write = fopen("$comment_file.txt", "a");
        fwrite($write,"<i>$ip_hash" . " - $date</i><br>" . "$message" . "<br><hr></hr>");
        fclose($write);
        header("Refresh:0");
    }


}

?>

        </td>
      </tr>
    </table>
<br><a href='index.php'><?php echo $lbl_back; ?></a>