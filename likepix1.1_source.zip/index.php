﻿<?php error_reporting(0); session_start(); if($_GET['lang'] != "") {$_SESSION['langs'] = $_GET['lang'];} $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      Likepix 1.1
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/likepix1.1/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Votado com sucesso!");
    }
  </script>


  <style type="text/css">   
    body{

      font-family: Arial;
      color: #666666;
      padding-left: 5%;
      padding-right: 5%;
    }
 
    input{

      border: 2px solid #DDD;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

    padding: 10px;
    }
  </style>

  <body>
      
    <table width='100%' style='background-color: #CCCCCC;'>
      <tr>
        <td width='1%'>        
          <a href='index.php'><img src='img/01.png' width='100px'></a>    
        </td>
        <td>         
          <div align='right'> 
            <form action="index.php" method="POST">    
              <a href='index.php?lang=eng'>Eng</a> / <a href='index.php?lang=pt-br'>Pt-br</a>
              <input type="text" placeholder="<?php echo $lbl_name; ?>" name="search">    
              <input type="text" placeholder="<?php echo $lbl_category; ?>" name="category">   
              <input type="submit" value="<?php echo $lbl_search; ?>" /> 
              
            </form>
          </div>
        </td>
      </tr>
    </table>
    <br>

      <?php echo $lbl_option_get; ?> /

      <a href='categories.php'><?php echo $lbl_u_categories; ?></a>
      

    <br><br>

<?php

if(!file_exists("categories")){

    mkdir("categories");
}

if(!file_exists("categories/thumbs")){

    mkdir("categories/thumbs");
}

if(!file_exists("categories/files")){

    mkdir("categories/files");
}


$start = $_GET['start'];  

$category = $_POST['category']; 
if ($category == ""){$category = $_GET['category'];}
	
if (!$start){$start = 0;}

$c = 0;
$limit = 20;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];
$search = strtolower($search);
$slash_break = 2;

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

if ($search != ""){

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        $item = explode('/', $picture);

        $picture_lowercase = strtolower($item[$slash_break]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($item[$slash_break]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $thumb_dir = '';

                $item = $item[$slash_break];

                $file_ext = substr($item, -3);
                $file_ext = strtolower($file_ext);

                if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){
                    $thumb_dir = $picture;
                } 

                if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                    $thumb_dir = 'img/nopic.jpg';

                }        

                if(file_exists('categories/thumbs/' . $item . '.jpg')){

                    $thumb_dir = 'categories/thumbs/' . $item . '.jpg';

                }   
 
                echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a></td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a> " . "</td></tr></table><hr></hr>";
                $search_break++; 
            }

        $entry++;
        if($search_break == $limit){break;}
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>$lbl_no_results</h1></div>";}

}else{

    if ($category == ""){
        
        $files_path = "categories/files";

    }else{

        $files_path = "categories/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        if ($c >= $ini and $c < $end){
 
            $thumb_dir = '';

            $item = explode('/', $picture);
            $item = $item[$slash_break];

            $file_ext = substr($item, -3);
            $file_ext = strtolower($file_ext);

                if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){
                    $thumb_dir = $picture;
                } 

                if(!file_exists("$thumb_dir") && $thumb_dir != $picture){

                    $thumb_dir = 'img/nopic.jpg';

                }        

                if(file_exists('categories/thumbs/' . $item . '.jpg')){

                    $thumb_dir = 'categories/thumbs/' . $item . '.jpg';

                }     

            echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a></td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>$lbl_like</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>$lbl_comment</u></a> " . "</td></tr></table><hr></hr>";
            $search_break++;             
        }

    $c++;
    if($search_break == $limit){break;}
    }

}

echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category'>$i</a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category'>$i</a>";
    }

} 

echo "</div>";

?>
    <div align='center'><br><br>
      <a href='likepix1.1_source.zip' style='text-decoration: none; color: #666666;'>sourcecode</a></a>
      <a href='#' style='text-decoration: none; color: #666666;' OnClick="alert('The likepix is a script for upload and search files without MySQL. The likepix is ​​not responsible for files uploaded by users or third parties.');">about</a></a>
    </div>
    <div id='ifrm'>

  </body>
</html>