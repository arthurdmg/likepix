
  The Likepix is a really basic and simple script for search, upload and organize files without MySQL using pure PHP
  Designed for simple hosting for avoiding MySQL delays or down (sometimes the query is more fast without MySQL)



Full version and updated (for commertial use)
---------------------------------------------
  https://www.paypal.com/donate/?hosted_button_id=66LQAKYZ4M77U



Donations
---------

  https://www.paypal.com/donate/?hosted_button_id=334TCQU44HKTJ
  Chave PIX : tectipix@gmail.com
  ETH: 0x3b0e87d57B53D85e0094b98ca8C0759fe001de27



Contract PHP Freelance or translations (eng to pt-br)
-----------------------------------------------------

  https://www.paypal.com/donate/?hosted_button_id=66LQAKYZ4M77U
  


Contact
-------

  tectipix@gmail.com
  https://likepix.blogspot.com/
  https://t.me/likepix




2022
_______________________________________________________________________________________________________________________________


Pt-br

   
    O Likepix � um sistema realmente simples e b�sico para pesquisa, organiza��o e envio de arquivos sem usar MySQL
    Projetado para hospedagem simples evitando lentid�o ou quedas no MySQL (�s vezes a consulta sem MySQL � mais r�pida)


Vers�o completa e atualizada (para uso comercial)
-------------------------------------------------
  https://www.paypal.com/donate/?hosted_button_id=66LQAKYZ4M77U



Doa��es
-------

  https://www.paypal.com/donate/?hosted_button_id=334TCQU44HKTJ
  Chave PIX : tectipix@gmail.com
  ETH: 0x3b0e87d57B53D85e0094b98ca8C0759fe001de27



Contratar servi�o de freelance em PHP ou tradutor (pt-br, ingl�s)
-------------------------------------------------------------------------

   https://www.paypal.com/donate/?hosted_button_id=66LQAKYZ4M77U
  


Contato
-------

  tectipix@gmail.com
  https://likepix.blogspot.com/
  https://t.me/likepix






