﻿<?php error_reporting(0); session_start(); $lang = $_SESSION['langs']; include("lang.php");?>

<html>
  <head>
    <title>
      <?php echo $lbl_u_categories; ?>
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <style type="text/css">   
    body{

      font-family: Arial;
      padding-left: 5%;
      padding-right: 5%;
      color: #666666;
    }
 
    input{

      border: 2px solid #DDD;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

    padding: 10px;
    }

  </style>

  <body>
  
   <table width='100%' style='background-color: #CCCCCC;'>
      <tr>
        <td width='1%'>
          <a href='index.php'><img src='img/01.png' width='100px'></a>        
        </td>
        <td>         
          <div align='right'> 
            <form action="index.php" method="POST">    
              <a href='index.php?lang=eng'>Eng</a> / <a href='index.php?lang=pt-br'>Pt-br</a>
              <input type="text" placeholder="<?php echo $lbl_name; ?>" name="search">    
              <input type="text" placeholder="<?php echo $lbl_category; ?>" name="category">   
              <input type="submit" value="<?php echo $lbl_search; ?>" />
            </form>
          </div>
        </td>
      </tr>
    </table>
    <br>

<?php

foreach (glob("categories/*") as $category){


    $name = explode('/', $category);

    echo "<a href='index.php?category=$name[1]'>$name[1]</a> /";

}

?>


    <div align='center'><br><br>
      © <i>Likepix</i> - 2022
    </div>
    <div id='ifrm'>
  </body>
</html>
