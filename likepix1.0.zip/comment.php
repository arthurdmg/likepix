﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Comentários
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>


  <style type="text/css">
  
    body{

      font-family: Courier;
    }

    a{

      color:#00FF00;      
    }

    i{

      color:#AAAAAA;
      text-decoration: none;
    }

  </style>

  <body>

    <div align='center'>

      <table width='80%' style='background-color: #CCCCCC;'>
        <tr>
          <td width='12%'>
            <a href='index.php'><img src='img/03.png' width='90%'></a>        
          </td>
          <td>         
         
          </td>
        </tr>
      </table>

    <table width='80%'  style="border: 1px solid #CCCCCC; padding: 20px;">
      <tr>
        <td> 
    
<?php

$thumb_check = explode('/',  $_GET['comment_file']);

$thumb_dir = $thumb_check[2];

if(!file_exists("categorias/thumbs/$thumb_dir.jpg")){
 
    $thumb_dir = 'img/nopic.jpg';
    echo "<div align='center'><img src='$thumb_dir'></div>";

}else{
              
    $thumb_dir = "categorias/thumbs/$thumb_dir.jpg";
    echo "<div align='center'><img src='$thumb_dir' width='75%'></div>";

}


?>

<?php

function ip() {

    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

if(file_exists($_GET['comment_file'])){

    $message = $_POST['message'];

    $comment_file = $_GET['comment_file'];

    $avoid_chars = array ('<', '>', "//");

    $message = str_replace($avoid_chars, "", $message); 

    $filesize = filesize("$comment_file.txt");

    if ($filesize > 5000){unlink("$comment_file.txt");}  

    echo "<form action='comment.php?comment_file=$comment_file' method='POST'>
      <br>
<div align='center'>
     Enviar comentário <input type='text' name='message' maxlength='50'>
     
     <input type='submit' name='submit_comment' value='Enviar' style='background-color: #EEEEEE;'>
</div>
     </form><br>";

    $ip = ip();

    $ip_hash = sha1($ip);

    $ip_nick = preg_replace('/(.)\1+/', '$1', $ip_hash);

    $comment_file = 'hashes/' . sha1($comment_file);

    echo "<div align='left'>";
    
    include("$comment_file" . ".txt"); 
    
    echo "</div>";

    $day = date("d");

    $month = date("m");

    $year = date("y");




    $date = $day . '/' . $month . '/' . $year;

    if ($message != ''){
        $write = fopen("$comment_file.txt", "a");
        fwrite($write,"<i>$ip_hash" . " - $date</i><br>" . "$message" . "<br><hr></hr>");
        fclose($write);
        header("Refresh:0");

    }


}

?>

        </td>
      </tr>
    </table>
<br><a href='index.php'>Voltar</a>