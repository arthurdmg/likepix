﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Likepix
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <style type="text/css">   
    body{

      font-family: Arial;
      padding-left: 5%;
      padding-right: 5%;
      color: #666666;
    }
 
    input{

      border: 2px solid #DDD;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

    padding: 10px;
    }
  </style>

  <body>
  
    <table width='100%' style='background-color: #CCCCCC;'>
      <tr>
        <td width='12%'>
          <a href='index.php'><img src='img/03.png' width='90%'></a>        
        </td>
        <td>         
          <div align='right'> 
            <form action="index.php" method="POST">      
              <input type="text" placeholder="nome" name="search">    
              <input type="text" placeholder="categoria" name="category">    
              <input type="submit" value="Pesquisar" /> &nbsp;&nbsp;&nbsp;&nbsp;
            </form>
          </div>
        </td>
      </tr>
    </table>

<br>

<?php

foreach (glob("categorias/*") as $category){


$name = explode('/', $category);

echo "<a href='index.php?category=$name[1]' >$name[1]</a> /";

}

?>


    <div align='center'><br><br>
      © <i>Likepix</i> - 2022
    </div>
    <div id='ifrm'>
  </body>
</html>
