﻿<?php error_reporting(0); ?>
  <style type="text/css">
    body{
      font-family: Arial;
    }

    a{

      color:#00FF00;
    }

    input{
    
        border: 2px solid #DDD;
        border-radius: 2px 2Px 2px 2px;
        padding: 5px;
        margin: 1px;
    }
  </style>


<div align='center'>


            <form enctype="multipart/form-data" action="upload_basic.php" method="POST">

              <table width='80%' style="border: 1px solid #CCCCCC; padding: 20px; background-color: #CCCCCC;">
               
         <tr><td>Enviar seu arquivo ou link</td></tr>
              </table>

              <table width='80%' style="border: 1px solid #CCCCCC; border-radius: 2px 2px 2px 2px; padding: 20px;">
              <tr>
              <td>Título</td>
              <td><input name="name" type="text" /></td>    
              </tr><tr>

              <td>Selecionar arquivo</td>
              <td><input name="file" type="file" /> ou enviar link <input name="links" type="text" /></td>
              </tr><tr>
               
              <td>Selecionar thumbnail </td>
              <td><input name="thumb" type="file"/> <a href='#' OnClick="alert('O thumbnail é a imagem, capa ou ilustração do seu arquivo. Deve ser no formato .jpg');">[?]</a>        
              </tr><tr>

              <td>Minha chave PIX</td>
              <td><input name="link" type="text" /></td>  
    
              <td><input type="submit" name="upload" value="Enviar" />

              </td>
              </tr>
              </table>
                  
            </form>

    <a href='index.php'>Voltar</a>
          </div>

<?php

$file = basename($_FILES["file"]["name"]);

$file = strtolower($file);

$target_dir = "files/";

$target_file = $target_dir . $file;

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if($_POST['name'] != ""){$target_file = $target_dir. $_POST['name'] . '.' . $imageFileType;}

$allow_upload = 1;

$msg_error = "";

if($imageFileType == "php") {
    $allow_upload = 0;
}

if(file_exists($target_file)){
    $msg_error = $msg_error . "Alguns erros foram detectados!<br><br>- Já existe um arquivo com esse nome. Tente enviar com um nome diferente.<br>";
    $allow_upload = 0;
}

if($allow_upload){
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "- Arquivo enviado com sucesso!<br>";
    } else {
        $allow_upload = 0;
        echo $msg_error;
    }
}

if($_POST['upload']){
    echo $msg_error;
} 

$target_dir = "thumbs/";

$target_file = $target_dir . basename($_FILES["thumb"]["name"]);

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if($_POST['name'] != ""){$target_file = $target_dir. $_POST['name'] . '.' . $imageFileType;}

$allow_upload2 = 1;

if($imageFileType != "jpg") {
    $msg_error = $msg_error . "- Seu thumbnail não está no formato .jpg!<br>"; 
    $allow_upload2 = 0;
}

if(file_exists($uploadfile)){
    $msg_error = $msg_error . "Sorry file exists!<br>";
    $allow_upload2 = 0;
}

if($allow_upload and $allow_upload2){
    if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $target_file . "." . $imageFileType)) {
        echo "- Thumbnail enviado com sucesso!<br>";
    } else {
    
        echo $msg_error;
    }
}


$avoid_chars = array ('<', '>');

$name = $_POST['name'];
$link = $_POST['links'];
$link_dir = "files/$name";

$link = str_replace($avoid_chars, "", $link); 

if(!file_exists("$link_dir")){

        $write = fopen("files/$name", "w");
        fwrite($write, "<?php include('../ads.php'); echo " . '"' . "<a href='$link'>Continuar</a>" . '"; ?>');
        fclose($write);
        echo "- Link enviado com sucesso!";

}else{

//echo "<br>- Já existe um link com esse nome! Tente outro nome";

}


?>