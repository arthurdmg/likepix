<?php error_reporting(0); ?>

<body style='background-color: #CCC; font-family: Arial; padding: 5px;'>

<div align='center'>
    <form action="index.php" method="post">
    <b><a href='index.php'>Home</a> -</b> <i>Link database seach</i>
        <input type="text" name="search" style="padding: 1%;" >
        <input type="submit" style="padding: 1%;" name="submit" value="Search">
    </form>
</div>

<hr></hr>

<?php

$url = $_GET['url'];

include("sql/conf.php");

if ($url != ""){

    $url = file_get_contents($url);

    $q = explode('"', $url);

    $day = date("d");

    $month = date("m");

    $year = date("y");



    
    $date = $year . '/' . $day . '/' . $month ;

    for($i = 0; $i < 1000; $i++){

        $link_check = substr($q[$i], 0, 4); 

        if ($link_check == "http" or $link_check == "magn"){

            echo $q[$i] . "<br>";
        
            $link = $q[$i];      

            $query = "INSERT INTO linkdb (url, date) VALUES ('$link', '$date')";
            $result = mysqli_query($db, $query); 
        
        }

    }
}

?>

<?php
$home = "index.php";

$search = $_POST["search"];

if ($_POST["search"] == ""){$search = $_GET['search'];}

$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$limit = 100;

$ini = $start * $limit;
$end = $ini + $limit;

$query = "SELECT * FROM linkdb WHERE url LIKE '%$search%' ORDER BY likes DESC LIMIT $ini, $limit";

$result = mysqli_query($db, $query);

$count = "";

echo "<div align='center'><table width='80%'><tr><td>";

    while ($row = mysqli_fetch_array($result)){
 
      $count++;
      $id = $row['0'];
      $url = $row['1'];

      echo "<a href='$url' target='_blank'>$url</a>";
      //echo " <a href='#' onClick='likeFrame(" . '"' . $id . '"' .  ")'><img src='symbols/thumb_up.png'></a>"; 
      //echo " <a href='#' onClick='deslikeFrame(" . '"' . $id . '"' .  ")'><img src='symbols/thumb_down.png'></a><br><br>";     
      echo "<br>";   

    }

echo "</td></tr></table><div align='center'>";

      if ($count == ""){echo "<br><br<br><br><br><br>No results!";}


echo "<div align='center'></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

} 


?>

<div id="ifrm">