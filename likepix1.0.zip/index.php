﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Likepix 1.0
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/likepix/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Votado com sucesso!");
    }
  </script>

  <style type="text/css">   
    body{

      font-family: Arial;
      color: #666666;
      padding-left: 5%;
      padding-right: 5%;
    }
 
    input{

      border: 2px solid #DDD;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }

    a{

    padding: 10px;
    }
  </style>

  <body>
  
    <table width='100%' style='background-color: #CCCCCC;'>
      <tr>
        <td width='12%'>
          <a href='index.php'><img src='img/03.png' width='90%'></a>        
        </td>
        <td>         
          <div align='right'> 
            <form action="index.php" method="POST">      
              <input type="text" placeholder="nome" name="search">    
              <input type="text" placeholder="categoria" name="category">    
              <input type="submit" value="Pesquisar" /> &nbsp;&nbsp;&nbsp;&nbsp;
            </form>
          </div>
        </td>
      </tr>
    </table>
    <br>

      <a href='upload.php'>Upload</a> /
      <a href='categorias.php'>Categorias</a>

    <br><br>

<?php

if(!file_exists("categorias/thumbs")){

    mkdir("categorias/thumbs");
}

if(!file_exists("categorias/files")){

    mkdir("categorias/files");
}


$start = $_GET['start'];  

$category = $_POST['category']; 
if ($category == ""){$category = $_GET['category'];}
	
if (!$start){$start = 0;}

$c = 0;
$limit = 20;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];
$search = strtolower($search);

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

if ($search != ""){

    if ($category == ""){
        
        $files_path = "categorias/files";
        $slash_break = 2;

    }else{

        $files_path = "categorias/$category";
        $slash_break = 2;
    }

    foreach (glob("$files_path/*") as $picture){


        $picture_filename = explode("/", $picture);
        $picture_lowercase = strtolower($picture_filename[$slash_break]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($picture_filename[$slash_break]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $item = explode('/', $picture);
                $item = $item[$slash_break];

                $thumb_dir = explode('/', $picture);
                $thumb_dir = 'categorias/thumbs/' . $thumb_dir[$slash_break] . '.jpg';

                if(!file_exists("$thumb_dir")){

                    $thumb_dir = 'img/nopic.jpg';

                }

                $file_ext = substr($item, -3);
                $file_ext = strtolower($file_ext);

                if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){
                    $thumb_dir = $picture;
                }             
 
                echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a></td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>Curtir</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>Comentar</u></a> " . "</td></tr></table><hr></hr>";
              
            }

        $entry++;
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>Nenhum resultado encontrado!</h1></div>";}

}else{

    if ($category == ""){
        
        $files_path = "categorias/files";

    }else{

        $files_path = "categorias/$category";
    }

    foreach (glob("$files_path/*") as $picture){


        if ($c >= $ini and $c < $end){

            $item = explode('/', $picture);
            $item = $item[2];

            $thumb_dir = explode('/', $picture);
            $thumb_dir = 'categorias/thumbs/' . $thumb_dir[2] . '.jpg';

            if(!file_exists("$thumb_dir")){

                $thumb_dir = 'img/nopic.jpg';
            }

            $file_ext = substr($item, -3);
            $file_ext = strtolower($file_ext);

            if($file_ext == 'jpg' or $file_ext == 'png' or $file_ext == 'gif' or $file_ext == 'peg'){
                $thumb_dir = $picture;
            }     

            echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a> </td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>Curtir</u></a><a href='comment.php?comment_file=$picture' target='_blank'><u>Comentar</u></a> " . "</td></tr></table><hr></hr>";
        
        }

    $c++;
    }

}

echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category'>$i</a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search&category=$category'>$i</a>";
    }

} 

echo "</div>";

?>
    <div align='center'><br><br>
      © <i>Likepix</i> - 2022<br><br>
    </div>

    <div align='center'>
 
      <a href='#' OnClick="alert('Se você deseja adquirir o código-fonte completo e atualizado basta realizar um PIX de R$ 100,00 para tectipix@gmail.com e enviar o comprovante para o nosso Telegram.')";>Versão completa</a> /
      <a href='#' OnClick="alert('Você pode adquirir uma conta premium por apenas R$ 60,00 no PIX tectipix@gmail.com')";>Comprar uma conta</a> /
      <a href='#' OnClick="alert('Se você deseja adquirir o nosso token você pode fazer um depósito de 10,00R$ para a chave PIX: tectipix@gmail.com')";>Comprar token</a> /
      <a href='#' OnClick="alert('Você pode doar ETH para nosso projeto! 0x3b0e87d57B53D85e0094b98ca8C0759fe001de27');">Doar ETH</a> /
      <a href='#' OnClick="alert('O Likepix não se responsabiliza pelo conteúdo postado pelos usuários. Em caso de dúvida ou remoção de algum item entrar em contato com tectipix@gmail.com');">Termos de Uso</a> /    
      <a href='https://t.me/likepix' target='_blank'>Telegram</a> /
      <a href='https://likepix.blogspot.com/' target='_blank'>Blog</a> /
      <a href='#' OnClick="alert('tectipix@gmail.com');">Contato</a><br><br>

      <a href='likepix1.0.zip'>Código-fonte</a> /
      <a href='#' OnClick="alert('Se você deseja ter a sua propaganda ou banner em nosso site entre em contato com tectipix@gmail.com');">Anúncios</a>


    </div>
    <div id='ifrm'>
  </body>
</html>
