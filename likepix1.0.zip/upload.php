﻿<?php error_reporting(0); ?>
  <style type="text/css">
    body{
      font-family: Arial;
    }

    a{
      color:#00FF00;
    }

input{
border: 2px solid #DDD;
border-radius: 2px 2Px 2px 2px;
padding: 5px;
margin: 1px;
}
  </style>


<div align='center'>


            <form enctype="multipart/form-data" action="upload.php" method="POST">

              <table width='80%' style="border: 1px solid #CCCCCC; padding: 20px; background-color: #CCCCCC;">
               
         <tr><td>Enviar seu arquivo ou link</td></tr>
              </table>

              <table width='80%' style="border: 1px solid #CCCCCC; border-radius: 2px 2px 2px 2px; padding: 20px;">
              <tr>
              <td>Título</td>
              <td><input name="name" type="text" /></td>    
              </tr><tr>

              <td>Selecionar arquivo</td>
              <td><input name="file" type="file" /> ou enviar link <input name="links" type="text" /></td>
              </tr><tr>
               
              <td>Selecionar thumbnail </td>
              <td><input name="thumb" type="file"/> <a href='#' OnClick="alert('O thumbnail é a imagem, capa ou ilustração do seu arquivo. Deve ser no formato .jpg');">[?]</a>        
              </tr><tr>

              <td>Categoria</td>
              <td><input name="category" type="text" /></td>  
              </tr><tr>

              <td>Minha chave PIX</td>
              <td><input name="pix" type="text" /></td>  
    
              <td><input type="submit" name="upload" value="Enviar" />

              </td>
              </tr>
              </table>
                  
            </form>

    <a href='index.php'>Voltar</a>
          </div>

<?php

$name = $_POST['name'];

$link = $_POST['links'];

$category = $_POST['category'];

$avoid_chars_category = array ('<', '>', '//', '.');

$category = str_replace($avoid_chars_category, "", $category); 

if($category != ""){

    mkdir("categorias/$category");
    $category_path = "categorias/$category/";

}else{

   $category_path = "categorias/files/";
   $category = "files";

}

$file = basename($_FILES["file"]["name"]);

$file = strtolower($file);

$target_dir = $category_path;

$target_file = $target_dir . $file;

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if($_POST['name'] != ""){$target_file = $target_dir. $_POST['name'] . '.' . $imageFileType;}

$allow_upload = 1;

$msg_error = "";

if($imageFileType == "php") {
    $allow_upload = 0;
}

if(file_exists($target_file)){
    $msg_error = $msg_error . "Alguns erros foram detectados!<br><br>- Já existe um arquivo com esse nome. Tente enviar com um nome diferente.<br>";
    $allow_upload = 0;
}

if($allow_upload){
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "- Arquivo enviado com sucesso!<br>";
    } else {
        $allow_upload = 0;
        echo $msg_error;
    }
}

if($_POST['upload']){
    echo $msg_error;
} 

$target_dir = "categorias/thumbs/";

$target_file = $target_dir . basename($_FILES["file"]["name"]);

$imageFileType = strtolower(pathinfo(basename($_FILES["thumb"]["name"]),PATHINFO_EXTENSION));

if($_POST['name'] != ""){$target_file = $target_dir. $_POST['name'] . '.' . $imageFileType;}

$allow_upload2 = 1;

if($imageFileType != "jpg") {
    $msg_error = $msg_error . "- Seu thumbnail não está no formato .jpg!<br>"; 
    $allow_upload2 = 0;
}

if(file_exists($target_file)){
    $msg_error = $msg_error . "Alguns erros foram detectados!<br><br>- Já existe um arquivo com esse nome. Tente enviar com um nome diferente.<br>";
    $allow_upload2 = 0;
}


if($allow_upload && $allow_upload2){
    if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $target_file . "." . $imageFileType)) {
        echo "- Thumbnail enviado com sucesso!<br>";
    } else {
    
        echo $msg_error;
    }
}

if($name != "" && $link != "" && $allow_upload2){
    if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $target_file)) {
        echo "- Thumbnail enviado com sucesso!<br>";
    } else {
    
        echo $msg_error;
    }
}


$avoid_chars = array ('<', '>');
$link_dir = "categorias/$category/$name";

$link = str_replace($avoid_chars, "", $link); 

if(!file_exists("categorias/$category/$name") && basename($_FILES["file"]["name"]) == ""){
 
        mkdir("categorias/$category");

        $write = fopen("categorias/$category/$name", "w");
        fwrite($write, "<iframe src='../../ads.html' width='100%' height='400px'></iframe><br><a href='$link'>Continuar</a>");
        fclose($write);
        echo "- Link enviado com sucesso!";
}
        $date = date("Ymd"); 

        mkdir("log/$date");
       
        $pix = $_POST['pix'];
        $pix = str_replace($avoid_chars, "", $pix); 

        $write = fopen("log/$date/log.html", "a");
        fwrite($write, "$name - $link - $file - $category - $pix - $date <br>");
        fclose($write);
       

?>