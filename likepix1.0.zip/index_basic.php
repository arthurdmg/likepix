﻿<?php error_reporting(0); ?>

<html>
  <head>
    <title>
      Likepix
    </title>
  <link rel="icon" href="img/logo_1.png">
  </head>

  <script>

    var host = "http://localhost/likepix/";
    function likeFrame(url){

      var ifrm = document.createElement("iframe");
      ifrm.setAttribute("src", host + 'like.php?like_file=' + url);
      ifrm.style.width = "100px";
      ifrm.style.height = "100px";
      ifrm.setAttribute("hidden", true);
      document.body.appendChild(ifrm);
      window.alert("Votado com sucesso!");
    }
  </script>

  <style type="text/css">   
    body{

      font-family: Arial;
      color: #00FF00;
      padding-left: 5%;
      padding-right: 5%;
    }
 
    input{

      border: 2px solid #DDD;
      border-radius: 2px 2Px 2px 2px;
      padding: 5px;
      margin: 1px;
    }
  </style>

  <body>
  
    <table width='100%' style='background-color: #CCCCCC;'>
      <tr>
        <td width='12%'>
          <a href='index_basic.php'><img src='img/03.png' width='90%'></a>        
        </td>
        <td>         
          <div align='right'> 
            <form action="index_basic.php" method="POST">      
              <input type="text" name="search">    
              <input type="submit" value="Pesquisar" /> &nbsp;&nbsp;&nbsp;&nbsp;
            </form>
          </div>
        </td>
      </tr>
    </table>

    <div align='cente'>
      <a href='upload.php'>Upload</a>
      <a href='https://t.me/likepix' target='_blank'>Telegram</a>
      <a href='Código-fonte'>Código-fonte</a>
      <a href='#' OnClick="alert('Se você deseja adquirir a versão completa do código-fonte basta realizar um PIX de R$ 100,00 para tectipix@gmail.com e enviar o comprovante para o nosso Telegram.')";>Versão completa</a>
      <a href='#' OnClick="alert('')";>Comprar uma conta</a>
      <a href='Código-fonte'>Como funciona?</a>
      <a href='#' OnClick="alert('O Likepix é um serviço simples de compartilhamento de arquivo e links');">Sobre</a>
      <a href='#' OnClick="alert('O Likepix não se responsabiliza pelo conteúdo postado pelos usuários. Em caso de dúvida ou remoção de algum item entrar em contato com tectipix@gmail.com');">Termos de Uso</a>
    </div>

<?php

if(!file_exists("categorias/thumbs")){

    mkdir("categorias/thumbs");
}

if(!file_exists("categorias/files")){

    mkdir("categorias/files");
}

$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$c = 0;
$limit = 20;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];
$search = strtolower($search);

if($_POST['upload'] != ""){echo $msg_error;}

if ($search == ""){$search = $_GET['search'];}

if ($search != ""){

    foreach (glob("files/*") as $picture){


        $picture_filename = explode("/", $picture);
        $picture_lowercase = strtolower($picture_filename[1]);

        $name = str_replace("$search", "", "$picture_lowercase");
        $name_len = strlen($name);
        $entry_len = strlen($picture_filename[1]);

        if ($entry_len > $name_len){

            if($entry >= $ini and $entry  < $end){

                $item = explode('/', $picture);
                $item = $item[1];

                $thumb_dir = explode('/', $picture);
                $thumb_dir = 'thumbs/' . $thumb_dir[1] . '.jpg';

                if(!file_exists("$thumb_dir")){

                    $thumb_dir = 'img/nopic.jpg';

                }

                echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a></td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>Curtir</u></a>&nbsp; <a href='comment.php?comment_file=$picture' target='_blank'><u>Comentar</u></a> " . "</td></tr></table><hr></hr>";
              
            }

        $entry++;
        }

    $c++;
    }

    if ($entry == 0){echo "<br><br><div align='center'><h1>Nenhum resultado encontrado!</h1></div>";}

}else{

    foreach (glob("files/*") as $picture){


        if ($c >= $ini and $c < $end){

            $item = explode('/', $picture);
            $item = $item[1];

            $thumb_dir = explode('/', $picture);
            $thumb_dir = 'thumbs/' . $thumb_dir[1] . '.jpg';

            if(!file_exists("$thumb_dir")){

                $thumb_dir = 'img/nopic.jpg';

            }

            echo "<table width='100%'><tr><td width='30%'><a href='$thumb_dir' target='_blank'><img src='$thumb_dir' width='100%'></a> </td><td width='4%'></td><td><h1><a href='$picture' target='_blank'>$item</a></h1>" . "<a href='#' onClick='likeFrame(" . '"' . $picture . '"' .  ");'><u>Curtir</u></a>&nbsp <a href='comment.php?comment_file=$picture' target='_blank'><u>Comentar</u></a> " . "</td></tr></table><hr></hr>";
        
        }

    $c++;
    }

}

echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index_basic.php?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index_basic.php?start=$i&search=$search'>$i/ </a>";
    }

} 

echo "</div>";

?>

    <div align='center'><br><br>
      © <i>Likepix</i> - 2022
    </div>
    <div id='ifrm'>
  </body>
</html>
